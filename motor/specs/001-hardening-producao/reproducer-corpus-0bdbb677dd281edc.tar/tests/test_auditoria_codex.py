"""Reproducoes de invariantes violados encontradas na auditoria Codex.

Estes testes sao deliberadamente vermelhos ate o hardening correspondente.
"""
from __future__ import annotations

import copy
import json
import sys
import threading
from decimal import Decimal
from pathlib import Path

import pytest
from langgraph.checkpoint.memory import InMemorySaver
from pydantic import ValidationError

from motor.curador import certificar_sombra, preparar_promocao_gated, rodar_sombra
from motor.composicao_orcamento import RotaOrcadaCertificada
from motor.eventos import LogEventos
from motor.eventos_schema import tipos, valido
from motor.grafo import construir_grafo
from motor.modelos import ClienteStub
from motor.orcamento import RepositorioOrcamento, RotaTentativaCusteada
from motor.politica import PoliticaGates
from motor.servico import GerenciadorJobs, _validar_job_id
from motor_painel.painel import parse_eventos


def _modelo() -> dict:
    return {
        "id": "executor",
        "tipo": "modelo",
        "papel": "executor",
        "objetivo": "produzir resultado",
        "entradas": {},
        "resultado_esperado": "texto",
        "rubrica": ["resultado correto"],
    }


def _spec(subagentes: list[dict], padrao: str = "fan_out_sintese") -> dict:
    return {
        "versao": "0.1",
        "padrao": padrao,
        "missao": {
            "id": "auditoria",
            "objetivo": "testar invariantes",
            "contexto": "",
            "criterios_cobertura": ["resultado aprovado"],
        },
        "restricoes": {
            "teto_custo": 1.0,
            "max_subagentes": len(subagentes),
            "max_tentativas": 1,
        },
        "subagentes": subagentes,
        "gates": [],
        "sintese": {"instrucao": "sintetize", "formato": "markdown"},
    }


def _ferramenta(entradas: dict | None = None) -> dict:
    return {
        "id": "tool",
        "tipo": "ferramenta",
        "ferramenta": "audit",
        "objetivo": "executar ferramenta",
        "entradas": entradas or {},
        "resultado_esperado": "exit code",
    }


def _rodar_grafo(tmp_path: Path, spec: dict, roteador, **kwargs):
    log = LogEventos(tmp_path / "eventos.jsonl")
    grafo = construir_grafo(
        ClienteStub(roteador),
        log,
        checkpointer=InMemorySaver(),
        politica=PoliticaGates(overrides={"plano": "prosseguir", "cobertura": "prosseguir"}),
        workspace_base=tmp_path / "runs",
        **kwargs,
    )
    try:
        resultado = grafo.invoke({"spec": spec}, {"configurable": {"thread_id": "audit"}})
    finally:
        log.fechar()
    eventos = [json.loads(linha) for linha in log.path.read_text(encoding="utf-8").splitlines()]
    return resultado, eventos


@pytest.mark.parametrize(
    "validador",
    [
        {"kind": "schema_json", "config": {}},
        {"kind": "contem", "config": {}},
        {"kind": "comando", "config": {"comando": ""}},
    ],
    ids=["schema-sem-schema", "contem-sem-requer", "comando-vazio"],
)
def test_s1_configuracao_invalida_falha_na_validacao_da_spec(validador):
    alvo = _modelo()
    no_validador = {
        "id": "validador",
        "tipo": "validador",
        "valida": "executor",
        "validador": validador,
        "depende_de": ["executor"],
        "objetivo": "validar",
        "resultado_esperado": "veredito",
    }

    from motor.spec import WorkflowSpec

    with pytest.raises(ValidationError):
        WorkflowSpec.model_validate(_spec([alvo, no_validador], "grafo_dependencias"))


def test_k3_verifier_exige_booleano_antes_de_aprovar(tmp_path):
    def roteador(papel, _prompt):
        respostas = {
            "executor": "rascunho",
            "verifier": json.dumps({"aprovado": "false", "motivo": "reprovado"}),
            "evaluator": json.dumps({"aprovado": True, "lacunas": []}),
            "synthesizer": "final",
        }
        return respostas[papel]

    resultado, _ = _rodar_grafo(tmp_path, _spec([_modelo()]), roteador)

    assert resultado["resultados"][0]["aprovado"] is False


def test_g4_excecao_do_executor_vira_resultado_e_evento_de_erro(tmp_path):
    def roteador(papel, _prompt):
        if papel == "executor":
            raise RuntimeError("falha injetada")
        return json.dumps({"aprovado": True, "lacunas": []})

    resultado, eventos = _rodar_grafo(tmp_path, _spec([_modelo()]), roteador)

    assert resultado["resultados"][0]["aprovado"] is False
    assert any(evento["evento"] == "executor.erro" for evento in eventos)


def test_c1_allowlist_nao_confunde_basename_com_executavel_autorizado(tmp_path):
    falso = tmp_path / "nao-confiavel" / "python3"
    falso.parent.mkdir()
    falso.write_text("#!/bin/sh\nprintf 'executou'\n", encoding="utf-8")
    falso.chmod(0o755)
    ferramentas = {"audit": {"comando": str(falso), "interpreta_saida": "exit_code"}}

    resultado, _ = _rodar_grafo(
        tmp_path,
        _spec([_ferramenta()]),
        lambda papel, _prompt: json.dumps({"aprovado": True, "lacunas": []})
        if papel == "evaluator"
        else "final",
        ferramentas=ferramentas,
        ferramentas_permitidas=["python3"],
    )

    assert resultado["resultados"][0]["aprovado"] is False


def test_c2_c4_validador_nao_escapa_workspace_por_placeholder(tmp_path):
    marcador = tmp_path / "fora-do-workspace.txt"
    validador = {
        "id": "validador",
        "tipo": "validador",
        "valida": "executor",
        "depende_de": ["executor"],
        "objetivo": "validar em sandbox",
        "resultado_esperado": "veredito",
        "entradas": {
            "modo": "-c",
            "codigo": f"from pathlib import Path; Path({str(marcador)!r}).write_text('executou')",
        },
        "validador": {
            "kind": "comando",
            "config": {"comando": f"{sys.executable} {{modo}} {{codigo}}"},
        },
    }

    _rodar_grafo(
        tmp_path,
        _spec([_modelo(), validador], "grafo_dependencias"),
        lambda papel, _prompt: (
            "saida"
            if papel == "executor"
            else "final"
            if papel == "synthesizer"
            else json.dumps({"aprovado": True, "lacunas": []})
        ),
        ferramentas_permitidas=[Path(sys.executable).name],
    )

    assert not marcador.exists()


def test_e1_todo_evento_emitido_pelo_curador_pertence_ao_schema():
    eventos = []

    def emitir(nome, _dados):
        eventos.append(nome)

    casos = [{"id": "1", "slot": "redator", "titular": {"aprovado": False, "custo_usd": 2.0}}]
    evidencia = rodar_sombra(
        {"slot": "redator", "titular": "atual", "candidato": "novo"},
        casos,
        lambda _caso, _modelo: {"aprovado": True, "custo_usd": 1.0},
        emitir,
    )
    certificacao = certificar_sombra(evidencia, emitir)
    preparar_promocao_gated(certificacao, emitir)

    assert set(eventos) <= tipos()


def test_e1_schema_rejeita_evento_sem_payload_obrigatorio():
    assert valido({"evento": "executor.chamado"}) is False


def test_e1_envelope_reserva_tipo_e_timestamp(tmp_path):
    log = LogEventos(tmp_path / "log.jsonl")
    log.evento("spec.recebida", evento="forjado", t=-1)
    log.fechar()

    evento = json.loads(log.path.read_text(encoding="utf-8"))
    assert evento["evento"] == "spec.recebida"
    assert evento["t"] >= 0


def test_e2_reabrir_log_preserva_historico_por_padrao(tmp_path):
    caminho = tmp_path / "log.jsonl"
    primeiro = LogEventos(caminho)
    primeiro.evento("spec.recebida")
    primeiro.fechar()
    segundo = LogEventos(caminho)
    segundo.evento("tarefa.concluida")
    segundo.fechar()

    assert [json.loads(linha)["evento"] for linha in caminho.read_text().splitlines()] == [
        "spec.recebida",
        "tarefa.concluida",
    ]


def test_e2_projecao_preserva_eventos_antes_de_tail_parcial(tmp_path):
    caminho = tmp_path / "log.jsonl"
    caminho.write_text('{"t": 0, "evento": "spec.recebida"}\n{"t":', encoding="utf-8")

    assert parse_eventos(caminho) == [{"t": 0, "evento": "spec.recebida"}]


def test_u1_runner_nao_pode_mutar_casos_held_out():
    casos = [{
        "id": "1",
        "slot": "redator",
        "entrada": {"texto": "original"},
        "titular": {"aprovado": True, "custo_usd": 2.0},
    }]
    original = copy.deepcopy(casos)

    def runner(caso, _modelo):
        caso["entrada"]["texto"] = "alterado"
        caso["titular"]["aprovado"] = False
        return {"aprovado": True, "custo_usd": 1.0}

    rodar_sombra({"slot": "redator", "titular": "atual", "candidato": "novo"}, casos, runner)

    assert casos == original


def test_u2_custo_parcial_do_candidato_e_incomparavel():
    casos = [
        {"id": "1", "slot": "redator", "titular": {"aprovado": True, "custo_usd": 0.02}},
        {"id": "2", "slot": "redator", "titular": {"aprovado": False, "custo_usd": 0.02}},
    ]
    resultados = iter([
        {"aprovado": True, "custo_usd": 0.01},
        {"aprovado": True, "custo_usd": None},
    ])
    evidencia = rodar_sombra(
        {"slot": "redator", "titular": "atual", "candidato": "novo"},
        casos,
        lambda _caso, _modelo: next(resultados),
    )

    assert certificar_sombra(evidencia)["status"] == "rejeitado"


def test_u2_aprovado_exige_booleano_estrito():
    casos = [{"id": "1", "slot": "redator", "titular": {"aprovado": False, "custo_usd": 0.02}}]
    evidencia = rodar_sombra(
        {"slot": "redator", "titular": "atual", "candidato": "novo"},
        casos,
        lambda _caso, _modelo: {"aprovado": "false", "custo_usd": 0.01},
    )

    assert evidencia["candidato"]["aprovados"] == 0
    assert certificar_sombra(evidencia)["status"] == "rejeitado"


def test_u2_certificacao_rejeita_agregados_sem_casos_e_proveniencia():
    evidencia = {
        "status": "nao_e_sombra",
        "slot": "redator",
        "casos": [],
        "titular": {"modelo": "atual", "taxa_aprovacao": 0.0, "custo_medio_usd": 2.0},
        "candidato": {"modelo": "novo", "taxa_aprovacao": 1.0, "custo_medio_usd": 1.0},
    }

    assert certificar_sombra(evidencia)["status"] == "rejeitado"


def test_u3_status_certificado_sem_evidencia_nao_gera_intencao():
    assert preparar_promocao_gated({"status": "certificado"})["status"] == "promocao_vetada"


@pytest.mark.parametrize("gate", ["plano", "cobertura", "promocao"])
def test_f3_auto_mode_nao_responde_gate_sensivel(gate):
    assert PoliticaGates(auto_mode=True).decisao_auto(gate) is None


def test_job_id_nao_aceita_segmentos_de_traversal():
    with pytest.raises(ValueError):
        _validar_job_id("..")


def test_resposta_concorrente_ao_gate_so_dispara_um_resume(tmp_path, monkeypatch):
    class TentativaNaoExecutavel:
        def cotar_tentativa(self):
            raise AssertionError("este teste nao executa modelo")

        def tentar_uma_vez(self):
            raise AssertionError("este teste nao executa modelo")

    def fabricar(papel, _prompt, _tentativa, requisitos):
        tipo = "verifier" if papel == "verifier" else "executor"
        provider = f"stub-provider-{tipo}"
        if requisitos.evitar_provedor == provider:
            return []
        return [RotaTentativaCusteada(
            f"stub:{tipo}", provider, TentativaNaoExecutavel(),
        )]

    jobs = GerenciadorJobs(
        db_path=tmp_path / "motor.db",
        cliente=ClienteStub(lambda *_: None),
        repositorio_orcamento=RepositorioOrcamento(tmp_path / "orcamento"),
        fabrica_tentativas_orcadas=fabricar,
        teto_bootstrap=Decimal("2"),
        rotas_certificadas=(
            RotaOrcadaCertificada(
                "stub:executor", "stub-provider-executor", frozenset({"executor"}),
            ),
            RotaOrcadaCertificada(
                "stub:verifier", "stub-provider-verifier", frozenset({"verifier"}),
            ),
        ),
    )
    barreira = threading.Barrier(2)
    inicios = []
    respostas = []

    def status(_job_id):
        barreira.wait()
        return {"estado": "gate_pendente"}

    monkeypatch.setattr(jobs, "status", status)
    monkeypatch.setattr(jobs, "_iniciar_thread", lambda *args: inicios.append(args))
    threads = [threading.Thread(target=lambda: respostas.append(jobs.responder_gate("job", "prosseguir"))) for _ in range(2)]
    try:
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
    finally:
        jobs._conn.close()

    assert len(inicios) == 1
    assert sum(resposta["estado"] == "em_execucao" for resposta in respostas) == 1
